Analizador COMTRADE — freeware 0.1, revisión 2
Versión: 0.1.1.0
Windows 10/11 x64. Descomprime el archivo y ejecuta AnalizadorComtrade.exe.
El ejecutable oficial se ofrece gratuitamente. El uso se rige por PolyForm Noncommercial 1.0.0, incluida en LICENSE.txt.
La licencia permite usos no comerciales con las excepciones que detalla el texto. Revisa LICENSE.txt antes de usar, modificar o distribuir el programa.
No requiere instalar Python ni dependencias de terceros; utiliza componentes del sistema Windows.
Los resultados son orientativos y deben ser revisados por personal de ingeniería.
