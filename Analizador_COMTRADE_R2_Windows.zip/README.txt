Analizador COMTRADE — freeware 0.1, revisión 2
Versión: 0.1.1.0
Windows 10/11 x64. Descomprime el archivo y ejecuta AnalizadorComtrade.exe.
No requiere instalar Python ni dependencias de terceros; utiliza componentes del sistema Windows.
Los resultados son orientativos y deben ser revisados por personal de ingeniería.
