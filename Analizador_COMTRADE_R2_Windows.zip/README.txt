Analizador COMTRADE - freeware 0.1, revision 2
Version: 0.1.1.0
Windows 10/11 x64. Descomprima el archivo y ejecute AnalizadorComtrade.exe.
No requiere Python ni dependencias de terceros; utiliza componentes del sistema Windows.
Los resultados son orientativos y deben ser revisados por personal de ingeniería.
